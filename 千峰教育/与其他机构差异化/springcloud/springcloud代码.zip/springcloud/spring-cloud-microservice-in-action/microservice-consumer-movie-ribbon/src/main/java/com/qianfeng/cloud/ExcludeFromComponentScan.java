package com.qianfeng.cloud;

public @interface ExcludeFromComponentScan {

}
