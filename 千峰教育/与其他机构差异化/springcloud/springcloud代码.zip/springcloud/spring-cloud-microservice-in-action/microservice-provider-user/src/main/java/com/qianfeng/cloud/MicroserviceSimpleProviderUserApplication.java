package com.qianfeng.cloud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient//声明连接到 eureka 服务端,等同于@EnableDiscoveryClient ,不过@EnableDiscoveryClient可以声明任意注册中心的客户端,比如 zookeeper 等
//EnableEurekaClient 声明就是 Eureka 客户端,类似于 spring中的 commpent 和 service 的区别
public class MicroserviceSimpleProviderUserApplication {

  public static void main(String[] args) {
    SpringApplication.run(MicroserviceSimpleProviderUserApplication.class, args);
  }
}
