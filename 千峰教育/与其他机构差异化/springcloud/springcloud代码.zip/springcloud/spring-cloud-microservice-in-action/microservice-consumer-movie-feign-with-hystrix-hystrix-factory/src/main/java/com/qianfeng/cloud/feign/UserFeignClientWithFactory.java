package com.qianfeng.cloud.feign;

public interface UserFeignClientWithFactory extends UserFeignClient {

}
