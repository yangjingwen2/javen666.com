package com.qianfeng.cloud.feign;

import org.springframework.cloud.netflix.feign.FeignClient;

import com.qianfeng.cloud.entity.User;
import com.qianfeng.config.Configuration1;

import feign.Param;
import feign.RequestLine;

@FeignClient(name = "microservice-provider-user", configuration = Configuration1.class)//指定配置类为Configuration1
public interface UserFeignClient {
  @RequestLine("GET /simple/{id}")//注意此处不是 RequestMapping 注解
  public User findById(@Param("id") Long id);//注意参数的注解由PathVariable变成Param注解
}