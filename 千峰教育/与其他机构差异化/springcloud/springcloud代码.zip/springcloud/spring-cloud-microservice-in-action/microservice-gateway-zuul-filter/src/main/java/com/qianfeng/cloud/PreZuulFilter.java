package com.qianfeng.cloud;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;

public class PreZuulFilter extends ZuulFilter {
  private static final Logger LOGGER = LoggerFactory.getLogger(PreZuulFilter.class);

  /**
   * 是否启用过滤器, true 启用
   * @return
   */
  @Override
  public boolean shouldFilter() {
    return true;
  }

  /**
   * 过滤器执行的时候
   * @return
   */
  @Override
  public Object run() {
    HttpServletRequest request = RequestContext.getCurrentContext().getRequest();
    String host = request.getRemoteHost();
    PreZuulFilter.LOGGER.info("请求的host:{}", host);
    return null;
  }

  /**
   * 过滤器的类型 比如前置后置等
   * @return
   */
  @Override
  public String filterType() {
    return "pre";
  }

  /**
   * 执行顺序,越小级别越高
   * @return
   */
  @Override
  public int filterOrder() {
    return 1;
  }

}
